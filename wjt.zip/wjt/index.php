<?php 
<html>
 
<head>
<link rel="stylesheet" type="text/css" href="Exercise2.css" >

<script src="Exercise2.js"></script>

</head>
 
<body onload="greet()" >
 
<!-- A introduction of the quiz.-->
<div>
<h1>-------------------------------------CTF理论知识小测验---------------------------------------</h1>
<h3>如果你认真做完这份题，我想你会对ctf有一个，
    初步的，更清晰的认知，并且我相信这会对你后面做题有很大帮助</h3>
<p>60分以上，就能拿flag啦！</p>
</div>
 

 
<!-- the quiz.-->
<form action="",method="post">
<fieldset>
<legend>题目部分</legend>
 
<!--part1-->
<fieldset>
<h3>单选（2分/题）(部分题目分数视难度增加)</h3>

<h3>-------------------------------------------web-------------------------------------------</h3>
<fieldset class ="question">
<p id="1">web 1: 对于http请求方式，以下哪个选项不全为正确</p>
<label><input type="radio" name="answer1" value="0"/>GET,POST,HEAD,DELETE</label>
<br />
<label ><input type="radio" name="answer1"  value="0"/>POST,HEAD,PUT,TRACE</label>
<br/>
<label ><input type="radio" name="answer1" value="2"/>OPTIONS,TRACE,CONNECT,URL</label>
</fieldset>
 
<fieldset class ="question">
<p id="2">web 2: 以下哪个http状态码表示请求成功</p>
<label><input type="radio" name="answer2" value="2" />200</label>
<br />
<label id="2"><input type="radio" name="answer2" value="0" />302<label>
<br/>
<label><input type="radio" name="answer2" value="0"/>404</label>
</fieldset>
 
<fieldset class ="question">
<p id="3">web 3: 以下哪个操作不能查看网页源码 </p>
<label id="3"><input type="radio" name="answer3" value="0" />Ctrl+u</label>
<br />
<label><input type="radio" name="answer3" value="0"/>F12</label>
<br/>
<label><input type="radio" name="answer3" value="2"/>ALT+s</label>
</fieldset>
 
<fieldset class ="question">
<p id="4">web 4:以下哪个不是抓包拦截工具 </p>
<label id="4"><input type="radio" name="answer4" value="2"/>Silenteye</label>
<br />
<label><input type="radio" name="answer4" value="0"/>burpsuite </label>
<br/>
<label><input type="radio" name="answer4" value="0"/>curl</label>
</fieldset>
 
<fieldset class ="question">
<p id="5">web 5: 以下哪个选项不全为可行的http请求头</p>
<label><input type="radio" name="answer5" value="0"/>User-Agent,Content-Type,Referer,Cookie</label>
<br />
<label><input type="radio" name="answer5" value="2"/>Referer,X-Forwarded-for,ETag,Accept</label>
<br/>
<label id="5"><input type="radio" name="answer5" value="0"/>Host,Accept-Encoding,Connection,Date</label>
</fieldset>
 
<fieldset class ="question">
<p id="6">web 6: 以下哪个不是本地主机ip</p>
<label><input type="radio" name="answer6" value="0"/>127.0.0.1</label>
<br />
<label id="6"><input type="radio" name="answer6" value="2"/>127.0.0.0</label>
<br/>
<label><input type="radio" name="answer6" value="0"/>localhost</label>
</fieldset>
 
<fieldset class ="question">
<p id="7">web 7: 在php中，对于eval()函数,以下说法错误的是</p>
<label><input type="radio" name="answer7" value="2" />eval('system('ls')')可以运行</label>
<br />
<label id="7"><input type="radio" name="answer7"  value="0"/>把字符串按照 PHP 代码来计算</label>
<br/>
<label><input type="radio" name="answer7"  value="0"/>是一个危险函数</label>
</fieldset>
 
<fieldset class ="question">
<p id="8">web 8:对于网页控制台，下列说法错误的是 </p>
<label><input type="radio" name="answer8" value="0"/>可以通过F12和鼠标右键检查元素打开</label>
<br />
<label id="8"><input type="radio" name="answer8" value="2"/>无法在控制台写入网页</label>
<br/>
<label><input type="radio" name="answer8"  value="0"/>可以运行js代码或者当前网页js脚本里的一些函数</label>
</fieldset>
 
<fieldset class ="question">
<p id="9">web 9:对于html，下列说法错误的是 </p>
<label id="9"><input type="radio" name="answer9"  value="2"/>无法在html中调用js脚本</label>
<br />
<label><input type="radio" name="answer9"  value="0"/>可以在网页中修改html元素的值</label>
<br/>
<label><input type="radio" name="answer9"  value="0"/>可以通过在url前加入view-source:查看源码</label>
</fieldset>

<fieldset class ="question">
    <p id="10">web 10 :以下哪个不具有网站目录扫描功能 </p>
    <label><input type="radio" name="answer10" value="0"/>dirsearch</label>
    <br />
    <label id="10"><input type="radio" name="answer10" value="0"/>御剑</label>
    <br/>
    <label><input type="radio" name="answer10"  value="2"/>robots协议</label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="20">web 11 :PHP中输入scandir("..")返回的是？ </p>
    <label><input type="radio" name="answer20" value="0"/>当前目录的父目录中的所有文件的数组
    </label>
    <br />
    <label id="20"><input type="radio" name="answer20" value="0"/>当前目录中的所有文件和子目录的数组
    </label>
    <br/>
    <label><input type="radio" name="answer20"  value="3"/>当前目录的父目录中的所有文件和子目录的数组
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="21">web 12 :哪个是参数过滤不严谨，能导致直接命令执行的函数？ </p>
    <label><input type="radio" name="answer21" value="2"/>shell_exec()</label>
    <br />
    <label id="21"><input type="radio" name="answer21" value="0"/>preg_replace()
    </label>
    <br/>
    <label><input type="radio" name="answer21"  value="0"/>call_user_func()
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="22">web 13 :文件上传后，php随机生成的临时文件名一般是？ </p>
    <label><input type="radio" name="answer22" value="4"/>php+4或者6位随机数字和大小写字母.tmp  
    </label>
    <br />
    <label id="22"><input type="radio" name="answer22" value="0"/>4或者6位随机数字和大小写字母+php.tmp
    </label>
    <br/>
    <label><input type="radio" name="answer22"  value="0"/>php.tmp
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="23">web 14 :当cat flag的cat被黑名单过滤后，我们可以用？ </p>
    <label><input type="radio" name="answer23" value="0"/>cta flag
    </label>
    <br />
    <label id="23"><input type="radio" name="answer23" value="0"/>ls flag
    </label>
    <br/>
    <label><input type="radio" name="answer23"  value="2"/>sort flag
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="24">web 15 :在Windows系统中可以察看开放端⼝情况的是。 </p>
    <label><input type="radio" name="answer24" value="0"/>Nbtstat</label>
    <br />
    <label id="24"><input type="radio" name="answer24" value="2"/>Netstat</label>
    <br/>
    <label><input type="radio" name="answer24"  value="0"/>Netshow</label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="25">web 16 :linux系统中查看主机ip地址的命令是？ </p>
    <label><input type="radio" name="answer25" value="0"/>ipconfig</label>
    <br />
    <label id="25"><input type="radio" name="answer25" value="2"/>ifconfig</label>
    <br/>
    <label><input type="radio" name="answer25"  value="0"/>netstat</label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="26">web 17 :请求头伪造IP地址时X-Forwarded-For被禁了我们还可以用 </p>
    <label><input type="radio" name="answer26" value="2"/>Client-Ip:
    </label>
    <br />
    <label id="26"><input type="radio" name="answer26" value="0"/>X-Client-For:
    </label>
    <br/>
    <label><input type="radio" name="answer26"  value="0"/>Y-Forwarded-For:
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="27">web 18 :sql注入时"="被过滤了我们可以用？ </p>
    <label><input type="radio" name="answer27" value="2"/>like</label>
    <br />
    <label id="27"><input type="radio" name="answer27" value="0"/>as</label>
    <br/>
    <label><input type="radio" name="answer27"  value="0"/>with</label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="28">web 19 :记录客户端状态的session保存在哪里？ </p>
    <label><input type="radio" name="answer28" value="0"/>浏览器的本地文件里
    </label>
    <br />
    <label id="28"><input type="radio" name="answer28" value="2"/>服务器端的文件或数据库
    </label>
    <br/>
    <label><input type="radio" name="answer28"  value="0"/>浏览器和服务器各自保存一份
    </label>
    </fieldset>
</div>
</fieldset>


<fieldset class ="question">
    <p id="29">web 20 :服务端模板注入漏洞的简称是？ </p>
    <label><input type="radio" name="answer29" value="0"/>CRSF</label>
    <br />
    <label id="29"><input type="radio" name="answer29" value="2"/>XSS</label>
    <br/>
    <label><input type="radio" name="answer29"  value="2"/>SSTI</label>
    </fieldset>

</fieldset>

<fieldset class="question">
    <p id="42">web21:对于DHCP说法错误的是</p>
    <label><input type="radio" name="answer42" value="0" />减少了管理员的工作量
    </label>
    <br />
    <label id="42"><input type="radio" name="answer42" value="0" />方便客户端的配置

    </label>
    <br />
    <label id="42"><input type="radio" name="answer42" value="0" />避免IP冲突
    </label>
    <br />
    <label><input type="radio" name="answer42" value="3" />只能为工作组下的用户分配IP地址
    </label>
</fieldset>

<fieldset class="question">
    <p id="47">web22:以下哪种不是ssrf绕过ip限制方法</p>
    <label><input type="radio" name="answer47" value="0" />修改IP地址进制格式
    </label>
    <br />
    <label id="47"><input type="radio" name="answer47" value="2" />双拼ip绕过
    </label>
    <br />
    <label id="47"><input type="radio" name="answer47" value="0" />用localhost代替
    </label>
</fieldset>


<fieldset class="question">
    <p id="44">web23:当服务器禁止我们上传文件，我们可以把文件改后缀然后压缩再上传,然后可以利用以下哪种协议读取</p>
    <label><input type="radio" name="answer44" value="2" />zip://协议
    </label>
    <br />
    <label id="44"><input type="radio" name="answer44" value="0" /> gopher://协议

    </label>
    <br />
    <label id="44"><input type="radio" name="answer44" value="0" />dic://协议
    </label>
    <br />
    <label><input type="radio" name="answer44" value="0" />data://协议
    </label>
</fieldset>

<fieldset class="question">
    <p id="45">web24:Linux系统中有多种配置IP地址的方法，使用下列的（）方法配置以后，新配置的IP地址可以立刻生效</p>
    <label><input type="radio" name="answer45" value="2" />使用命令：netconfig
    </label>
    <br />
    <label id="45"><input type="radio" name="answer45" value="0" />使用命令：ipconfig

    </label>
    <br />
    <label id="45"><input type="radio" name="answer45" value="3" />ifconfig
    </label>
    <br />
    <label><input type="radio" name="answer45" value="0" />修改网卡配置文件/etc/sysconfig/network-scripts/ifcfg-eth0
    </label>
</fieldset>

<fieldset class="question">
    <p id="48">web25:分析如下的JavaScript代码段， eval(“a=3;b=2;alert(a+b)”); 运行后以下描述正确的是？</p>
    <label><input type="radio" name="answer48" value="0" />弹出窗口显示undefined
    </label>
    <br />
    <label id="48"><input type="radio" name="answer48" value="0" />b的值为null

    </label>
    <br />
    <label id="48"><input type="radio" name="answer48" value="2" />弹出窗口显示5
    </label>
    <br />
    <label><input type="radio" name="answer48" value="0" />a的值为undefined
    </label>
</fieldset>



<h3>-------------------------------------------misc-------------------------------------------</h3>

<fieldset class ="question">
    <p id="11">misc1:以下哪个不可以查看文件的16进制数据 </p>
    <label><input type="radio" name="answer11" value="0"/>010 Editor</label>
    <br />
    <label id="11"><input type="radio" name="answer11" value="2"/>notepad</label>
    <br/>
    <label><input type="radio" name="answer11"  value="0"/>winhex</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="12">misc2:以下哪个选项不全是图片或音频隐写工具 </p>
    <label><input type="radio" name="answer12" value="0"/>zsteg，stegsolve，steghide</label>
    <br />
    <label id="12"><input type="radio" name="answer12" value="2"/>wbstego4，Audacity，nmap</label>
    <br/>
    <label><input type="radio" name="answer12"  value="0"/>mp3steg，SilentEye，sstv</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="13">misc3:以下哪个工具不能分离文件里的文件 </p>
    <label><input type="radio" name="answer13" value="0"/>binwalk</label>
    <br />
    <label id="13"><input type="radio" name="answer13" value="2"/>bandzip</label>
    <br/>
    <label><input type="radio" name="answer13"  value="0"/>foremost</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="14">misc4:哪个选项的文件头和文件尾不对应 </p>
    <label><input type="radio" name="answer14" value="0"/>文件头：FFD8FF 文件尾：FF D9</label>
    <br />
    <label id="14"><input type="radio" name="answer14" value="0"/>文件头：89504E47 文件尾：AE 42 60 82</label>
    <br/>
    <label><input type="radio" name="answer14"  value="2"/>文件头：504B0304  文件尾：52617221</label>
    </fieldset>

</fieldset>

<fieldset class="question">
    <p id="46">misc5:要用哪种文本风格查看word2013文档的内容，才能正常显示文档中的中文文字？</p>
    <label><input type="radio" name="answer46" value="0" />GB2312
    </label>
    <br />
    <label id="46"><input type="radio" name="answer46" value="0" />GB18030

    </label>
    <br />
    <label id="46"><input type="radio" name="answer46" value="0" />Unicode
    </label>
    <br />
    <label><input type="radio" name="answer46" value="2" />UTF-8
    </label>
</fieldset>

<fieldset class="question">
    <p id="43">misc6:哪些操作容易磨损硬盘，故不应经常使用</p>
    <label><input type="radio" name="answer43" value="0" />高级格式化
    </label>
    <br />
    <label id="43"><input type="radio" name="answer43" value="2" />低级格式化

    </label>
    <br />
    <label id="43"><input type="radio" name="answer43" value="0" />硬盘分区
    </label>
    <br />
    <label><input type="radio" name="answer43" value="0" />向硬盘拷贝文件
    </label>
</fieldset>






<h3>-------------------------------------------pwn-------------------------------------------</h3>
<fieldset class ="question">
    <p id="15">pwn1:	GCC编译不包括以下哪个阶段 </p>
    <label><input type="radio" name="answer15" value="0"/>预处理</label>
    <br />
    <label id="15"><input type="radio" name="answer15" value="0"/>汇编</label>
    <br/>
    <label><input type="radio" name="answer15"  value="2"/>链接</label>
    <br/>
    <label id="15"><input type="radio" name="answer15" value="2"/>编辑</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="16">pwn2:在Linux系统中，能列出文件信息的命令是 </p>
    <label><input type="radio" name="answer16" value="2"/>ls</label>
    <br />
    <label id="16"><input type="radio" name="answer16" value="0"/>whoami</label>
    <br/>
    <label id="16"><input type="radio" name="answer16" value="0"/>cat</label>
    <br/>
    <label><input type="radio" name="answer16"  value="0"/>touch</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="17">pwn3:以下哪项保护用于对抗栈溢出攻击 </p>
    <label><input type="radio" name="answer17" value="0"/>NX保护</label>
    <br />
    <label id="17"><input type="radio" name="answer17" value="4"/>Stack Canaries</label>
    <br/>
    <label id="17"><input type="radio" name="answer17" value="0"/>PIE</label>
    <br/>
    <label><input type="radio" name="answer17"  value="0"/>ASLR</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="18">pwn4:在C语言中，以下不属于安全函数的是</p>
    <label><input type="radio" name="answer18" value="0"/>fgets</label>
    <br />
    <label id="18"><input type="radio" name="answer18" value="2"/>gets</label>
    <br/>
    <label id="18"><input type="radio" name="answer18" value="0"/>scanf_s</label>
    <br/>
    <label><input type="radio" name="answer18"  value="0"/>vsnprintf</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="19">pwn5:以下哪项保护能使栈上的shellcode不可执行 </p>
    <label><input type="radio" name="answer19" value="4"/>NX保护</label>
    <br />
    <label id="19"><input type="radio" name="answer19" value="0"/>Stack Canaries</label>
    <br/>
    <label id="19"><input type="radio" name="answer19" value="0"/>PIE</label>
    <br/>
    <label><input type="radio" name="answer19"  value="0"/>ASLR</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="30">pwn6:下列哪条指令能查看Linux系统的历史命令执行记录</p>
    <label><input type="radio" name="answer30" value="0"/>history</label>
    <br />
    <label id="30"><input type="radio" name="answer30" value="2"/>cat‌‌‌‌‍‌﻿‬ ~/‌‌‌‌‍‌‌‬.‌‌‌‌‍‌‌‬bash_‌‌‌‌‍‌‌‬history</label>
    <br/>
    <label id="30"><input type="radio" name="answer30" value="0"/>ls</label>
    <br/>
    <label><input type="radio" name="answer30"  value="0"/>grep history</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="31">pwn7:文件头为7f 45 4c 46的文件一般是</p>
    <label><input type="radio" name="answer31" value="2"/>ELF文件</label>
    <br />
    <label id="31"><input type="radio" name="answer31" value="0"/>bmp图片文件</label>
    <br/>
    <label id="31"><input type="radio" name="answer31" value="0"/>php源码文件</label>
    <br/>
    <label><input type="radio" name="answer31"  value="0"/>pcapng流量包文件</label>
    </fieldset>

</fieldset>

<fieldset class ="question">
    <p id="32">pwn8:exec 1>&0意思是</p>
    <label><input type="radio" name="answer32" value="0"/>将数字1输出到地址为0的指针</label>
    <br />
    <label id="32"><input type="radio" name="answer32" value="4"/>将标准输出流重定向到标准输入流 </label>
    <br/>
    <label id="32"><input type="radio" name="answer32" value="0"/>执行一种运算，最终返回一个布尔值</label>
    
    </fieldset>

</fieldset>

<fieldset class="question">
    <p id="33">pwn9:安卓手机常用数据库格式为</p>
    <label><input type="radio" name="answer33" value="0" />Mysql</label>
    <br />
    <label id="33"><input type="radio" name="answer33" value="0" />redis</label>
    <br />
    <label id="33"><input type="radio" name="answer33" value="3" />sqlite3</label>
    <br />
    <label><input type="radio" name="answer33" value="0" />psql</label>
</fieldset>



<h3>-------------------------------------------reverse-------------------------------------------</h3>
<fieldset class="question">
    <p id="34">reverse1:下列哪个软件是查壳工具</p>
    <label><input type="radio" name="answer34" value="0" />jadx</label>
    <br />
    <label id="34"><input type="radio" name="answer34" value="0" />Visual Studio Code
    </label>
    <br />
    <label id="34"><input type="radio" name="answer34" value="0" />UPX Shell
    </label>
    <br />
    <label><input type="radio" name="answer34" value="2" />exeinfope</label>
</fieldset>

<fieldset class="question">
    <p id="35">reverse2:以下哪个软件是拆壳工具</p>
    <label><input type="radio" name="answer35" value="0" />dnSpy</label>
    <br />
    <label id="35"><input type="radio" name="answer35" value="2" />UPX Shell
    </label>
    <br />
    <label id="35"><input type="radio" name="answer35" value="0" />IDA
    </label>
    <br />
    <label><input type="radio" name="answer35" value="0" />GDA</label>
</fieldset>

<fieldset class="question">
    <p id="36">reverse3:以下可以反编译.exe文件的工具是哪一个？</p>
    <label><input type="radio" name="answer36" value="0" />jadx</label>
    <br />
    <label id="36"><input type="radio" name="answer36" value="0" />keil
    </label>
    <br />
    <label id="36"><input type="radio" name="answer36" value="2" />IDA
    </label>
    <br />
    <label><input type="radio" name="answer36" value="0" />Visual Studio Code
    </label>
</fieldset>

<fieldset class="question">
    <p id="37">reverse4:以下文件类型是不能进行反编译的</p>
    <label><input type="radio" name="answer37" value="2" />.txt</label>
    <br />
    <label id="37"><input type="radio" name="answer37" value="0" />.exe
    </label>
    <br />
    <label id="37"><input type="radio" name="answer37" value="0" />.apk
    </label>
    <br />
    <label><input type="radio" name="answer37" value="0" />.pyc
    </label>
</fieldset>

<fieldset class="question">
    <p id="38">reverse5:以下哪些不是安卓逆向用的工具</p>
    <label><input type="radio" name="answer38" value="0" />IDA</label>
    <br />
    <label id="38"><input type="radio" name="answer38" value="0" />AndroidKiller
    </label>
    <br />
    <label id="38"><input type="radio" name="answer38" value="0" />GDA
    </label>
    <br />
    <label><input type="radio" name="answer38" value="2" />exeinfope
    </label>
</fieldset>

<fieldset class="question">
    <p id="39">reverse6:以下叙述中正确的是</p>
    <label><input type="radio" name="answer39" value="4" />如果企图通过一个空指针来访问一个存储单元，将会得到一个出错信息
    </label>
    <br />
    <label id="39"><input type="radio" name="answer39" value="0" />即使不进行强制类型转换，在进行指针赋值运算时，指针变量的基类86截图型也可以不同

    </label>
    <br />
    <label id="39"><input type="radio" name="answer39" value="0" />设变量p是一个指针变量，则语句p=0;是非法的，应该使用p=NULL; 

    </label>
    <br />
    <label><input type="radio" name="answer39" value="0" />指针变量之间不能用关系运算符进行比较
    </label>
</fieldset>

<fieldset class="question">
    <p id="40">reverse7:以下选项中，能用作数据常量的是</p>
    <label><input type="radio" name="answer40" value="0" />o115</label>
    <br />
    <label id="40"><input type="radio" name="answer40" value="4" />0112
    </label>
    <br />
    <label id="40"><input type="radio" name="answer40" value="0" />1.5E1.5

    </label>
    <br />
    <label><input type="radio" name="answer40" value="0" />0xfp
    </label>
</fieldset>


<fieldset class="question">
    <p id="41">reverse8:下列哪一个运算结果可以让k=6</p>
    <label><input type="radio" name="answer41" value="0" />int a=6,k=0; k=a==6;
    </label>
    <br />
    <label id="41"><input type="radio" name="answer41" value="0" />int j=3,k=0;k=j%3;

    </label>
    <br />
    <label id="41"><input type="radio" name="answer41" value="3" />int j=3,k=1;++k,k*=j;
    </label>
    <br />
    <label><input type="radio" name="answer41" value="0" />int a=6,k=2;k^=a;
    </label>
</fieldset>













<h3>-------------------------------------------crypto-------------------------------------------</h3>
<fieldset class="question">
    <p id="49">crypto1:哪种密码算法运用字母频率分析法最有效</p>
    <label><input type="radio" name="answer49" value="0" />置换密码 
    </label>
    <br />
    <label id="49"><input type="radio" name="answer49" value="2" />单表代换密码

    </label>
    <br />
    <label id="49"><input type="radio" name="answer49" value="0" />多表代换密码
    </label>
    <br />
    <label><input type="radio" name="answer49" value="0" />序列密码
    </label>
</fieldset>


<fieldset class="question">
    <p id="50">crypto2:AES结构由以下四个模块组成，其中是非线性模块的是</p>
    <label><input type="radio" name="answer50" value="0" />行位移 
    </label>
    <br />
    <label id="50"><input type="radio" name="answer50" value="0" />列混淆

    </label>
    <br />
    <label id="50"><input type="radio" name="answer50" value="0" />轮密钥加
    </label>
    <br />
    <label><input type="radio" name="answer50" value="4" />字节代换
    </label>
</fieldset>



<fieldset class="question">
    <p id="51">crypto3:下面那个不是hash函数具有的特性</p>
    <label><input type="radio" name="answer51" value="0" />单向性 
    </label>
    <br />
    <label id="51"><input type="radio" name="answer51" value="0" />抗碰撞性

    </label>
    <br />
    <label id="51"><input type="radio" name="answer51" value="3" />可逆性
    </label>
    <br />
    <label><input type="radio" name="answer51" value="0" />压缩性
    </label>
</fieldset>


<fieldset class="question">
    <p id="52">crypto4:下面哪一项不主要应用hash函数</p>
    <label><input type="radio" name="answer52" value="0" />文件校验 
    </label>
    <br />
    <label id="52"><input type="radio" name="answer52" value="0" />数字签名
    </label>
    <br />
    <label id="52"><input type="radio" name="answer52" value="3" />数据加密
    </label>
    <br />
    <label><input type="radio" name="answer52" value="0" />鉴权协议
    </label>
</fieldset>

<fieldset class="question">
    <p id="53">crypto5:以下哪些python库为RSA加解密常用</p>
    <label><input type="radio" name="answer53" value="0" />gmpy2 
    </label>
    <br />
    <label id="53"><input type="radio" name="answer53" value="0" />libnum
    </label>
    <br />
    <label id="53"><input type="radio" name="answer53" value="0" />Crypto.Util.number
    </label>
    <br />
    <label><input type="radio" name="answer53" value="2" />hashlib
    </label>
</fieldset>

<fieldset class="question">
    <p id="54">crypto6:下列哪些不属于单表代换密码</p>
    <label><input type="radio" name="answer54" value="0" />Caesar 
    </label>
    <br />
    <label id="54"><input type="radio" name="answer54" value="2" />Vigenere 
    </label>
    <br />
    <label id="54"><input type="radio" name="answer54" value="0" />仿射密码
    </label>
    <br />
    <label><input type="radio" name="answer54" value="0" />Atbash 
    </label>
</fieldset>







<button type="button" onclick="coreCount()" >提交</button>

</fieldset>
 
</form>
 
 
</body>
 
</html>
?>