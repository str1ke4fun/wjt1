
 
function greet()
{
	

		document.onkeydown=function(){
			var e = window.event||arguments[0];
			if(e.keyCode==123){
				//F12
				return false;
			}else if((e.ctrlKey)&&(e.shiftKey)&&(e.keyCode==73)){
				//ctrl + shift + i
				
				return false;
			}else if((e.ctrlKey)&&(e.keyCode==85)){
				//ctrl + U
				
				return false;
			}else if((e.ctrlKey)&&(e.keyCode==83)){
				//ctrl + U
				
				return false;
			}
		}
		document.oncontextmenu=function(){
			//右击
			
			return false;
		}
		}
 
function thanks()
{
	alert("Thanks for your attention.");
}
 
function changeColor(obj)
{
 
	obj.style.background="powderblue";
}
 
function coreCount()
{
	var cores=0;
	var qestions=document.getElementsByClassName("question")
	for(var i=0;i<qestions.length;i++)
	{
		var count=0;
		var flag=1;
		var answer=document.getElementsByName("answer"+(i+1));
		for(var j=0;j<answer.length;j++)
		{
			if(answer[j].checked)
			{
				if(answer[j].value*1<0)
				{
					flag=0;
					break;
				}
				else
					count+=answer[j].value*1;
			}
		}
		if(flag==1)
			cores+=count;
	}
	if(cores<60){
	alert("Your score is "+cores);
	}
	if (cores>=60){	
	alert("HZCTF{test}");
	}
}
 
function showWhichWrong()
{
	var qestions=document.getElementsByClassName("question")
	for(var i=0;i<qestions.length;i++)
	{
		var answer=document.getElementsByName("answer"+(i+1));
		for(var j=0;j<answer.length;j++)
		{
			if(answer[j].checked)
			{
				if(answer[j].value*1<=0)
				{
					x=document.getElementById(i+1);
					x.style.color="red";
				}
			}
		}
	}
	for(var i=0;i<qestions.length;i++)
		{
			var answer=document.getElementsByName("answer"+(i+1));
			for(var j=0;j<answer.length;j++)
			{
				if(!answer[j].checked)
				{
					if(answer[j].value*1>0)
					{
						answer[j].style.backgroundColor="red";
					}
				}
			}
		}		
}